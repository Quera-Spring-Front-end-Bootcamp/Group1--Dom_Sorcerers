class Strings {
  static registerBtn = "ثبت نام";
  static loginBtn = "ورود";
  static loginText = "قبلا ثبت‌نام کرده‌ای؟";
  static registerText = "ثبت‌نام نکرده‌ای؟";
}
export default Strings;
